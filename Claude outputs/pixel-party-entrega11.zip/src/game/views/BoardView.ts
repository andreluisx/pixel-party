import type Phaser from 'phaser';
import type { GameUpdate, PublicGame } from '@shared/protocol';
import type { GEvent } from '@shared/game/engine';
import { REINO_DO_CASTELO } from '@shared/board/maps/reino-do-castelo';
import { SLOT_COLORS } from '@shared/types';
import type { BridgeClient } from '@/net/bridge';
import { sfx } from '../audio/sfx';
import { PixelNumber, popup } from './pixelNumber';

const W = 480, H = 270;
const WORLD = REINO_DO_CASTELO.world;
const TILE = Object.fromEntries(REINO_DO_CASTELO.tiles.map((t) => [t.id, t]));
const col = (hex: string) => parseInt(hex.slice(1), 16);
const OFFS: Record<number, number[]> = { 1: [0], 2: [-5, 5], 3: [-8, 0, 8], 4: [-10, -3.5, 3.5, 10] };

interface Token { pid: string; slot: number; sprite: Phaser.GameObjects.Sprite; shadow: Phaser.GameObjects.Image; flag: Phaser.GameObjects.Image; tile: string; busy: number; px: number; py: number }
interface Chip { c: Phaser.GameObjects.Container; bg: Phaser.GameObjects.Rectangle; coins: PixelNumber; stars: PixelNumber; arrow: Phaser.GameObjects.Image; lastCoins: number; lastStars: number }

/** Tabuleiro: só desenha o que o servidor decidiu. Entradas viram pedidos (rolar, escolher caminho, comprar). */
export class BoardView {
  private tokens = new Map<string, Token>();
  private chips = new Map<string, Chip>();
  private game: PublicGame;
  private active = '';
  private star!: Phaser.GameObjects.Image;
  private glow!: Phaser.GameObjects.Ellipse;
  private picks: Phaser.GameObjects.GameObject[] = [];
  private picksKey = '';
  private dice!: Phaser.GameObjects.Sprite;
  private remaining!: PixelNumber;
  private roundTxt!: PixelNumber;
  private starPtr!: Phaser.GameObjects.Image;
  private rolling = 0;
  private keyHandler: (ev: KeyboardEvent) => void;
  private cam: Phaser.Cameras.Scene2D.Camera;
  private objs: Phaser.GameObjects.GameObject[] = [];
  private dyn: Phaser.GameObjects.GameObject[] = [];
  private dynKey = '';

  constructor(private scene: Phaser.Scene, private client: BridgeClient) {
    this.cam = scene.cameras.main;
    this.cam.setBounds(0, 0, WORLD.w, WORLD.h);
    const pend = client.drainGame?.() ?? [];
    const last = pend[pend.length - 1] ?? client.state.game;
    this.game = last!.game;
    this.active = this.game.order[this.game.turn] ?? '';

    scene.add.image(0, 0, 'board-bg').setOrigin(0, 0).setDepth(0);
    // casas
    for (const t of REINO_DO_CASTELO.tiles) this.objs.push(scene.add.image(t.x, t.y + 1, `tile-${t.type}`).setDepth(5));
    // zonas clicáveis (toque/mouse): só valem quando a casa é uma escolha válida
    for (const t of REINO_DO_CASTELO.tiles) {
      const z = scene.add.zone(t.x, t.y, 28, 28).setInteractive({ useHandCursor: true }).setDepth(50);
      z.on('pointerdown', () => { const aw = this.client.state.game?.waiting; if (aw?.kind === 'fork' && aw.pid === this.client.state.you && aw.choices.includes(t.id)) { sfx.select(); this.client.choose?.(t.id); } });
    }
    // estrela
    const st = TILE[this.game.starTile]!;
    this.glow = scene.add.ellipse(st.x, st.y - 8, 26, 26, 0xffe08a, 0.35).setDepth(6);
    this.star = scene.add.image(st.x, st.y - 12, 'big-star').setDepth(40);
    scene.tweens.add({ targets: this.star, y: '-=4', duration: 700, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });
    scene.tweens.add({ targets: this.glow, scale: 1.35, alpha: 0.15, duration: 700, yoyo: true, repeat: -1 });
    // peões
    for (const p of this.game.players) {
      const t = TILE[p.tile]!;
      const shadow = scene.add.image(t.x, t.y, 'shadow').setDepth(9);
      const sprite = scene.add.sprite(t.x, t.y, `char-${p.characterId}`, 0).setOrigin(0.5, 0.85);
      const flag = scene.add.image(t.x, t.y - 22, 'marker').setTint(col(SLOT_COLORS[p.slot]!)).setDepth(60);
      this.tokens.set(p.id, { pid: p.id, slot: p.slot, sprite, shadow, flag, tile: p.tile, busy: 0, px: t.x, py: t.y });
    }
    this.restack(true);
    this.buildHud();
    this.syncDynamic();
    // teclado
    this.keyHandler = (ev) => this.onKey(ev);
    scene.input.keyboard!.on('keydown', this.keyHandler);
    scene.input.keyboard!.addCapture('UP,DOWN,LEFT,RIGHT,SPACE');
    const t0 = TILE[this.tokens.get(this.active)?.tile ?? 'R00']!;
    this.cam.setScroll(this.clampX(t0.x - W / 2), this.clampY(t0.y - H / 2));
    if (last) this.handle(last.events);
  }

  private clampX = (x: number) => Math.max(0, Math.min(WORLD.w - W, x));
  private clampY = (y: number) => Math.max(0, Math.min(WORLD.h - H, y));

  // ---------------------------------------------------------------- HUD
  private buildHud() {
    const s = this.scene;
    const ps = this.game.players;
    const cw = Math.floor((W - 8 - 3 * 4) / 4);
    ps.forEach((p, i) => {
      const x = 4 + i * (cw + 4), y = 3;
      const c = s.add.container(x, y).setScrollFactor(0).setDepth(100);
      const bg = s.add.rectangle(0, 0, cw, 25, 0x1b1030, 0.85).setOrigin(0, 0).setStrokeStyle(1, col(SLOT_COLORS[p.slot]!));
      const face = s.add.sprite(10, 22, `char-${p.characterId}`, 0).setOrigin(0.5, 1).setScale(1);
      const name = new PixelNumber(s, 0, 0, 1, 0xf6ecd2, 0); name.set(p.name.toUpperCase().slice(0, 7));
      name.container.setPosition(22 + 14, 3);
      const coin = s.add.sprite(0, 0, 'coin', 0).setOrigin(0, 0);
      coin.setPosition(21, 12);
      const coins = new PixelNumber(s, 0, 0, 2, 0xffe08a, 0); coins.container.setPosition(40, 12);
      const star = s.add.image(0, 0, 'big-star').setOrigin(0, 0).setScale(0.5).setPosition(cw - 24, 13);
      const stars = new PixelNumber(s, 0, 0, 2, 0xffffff, 0); stars.container.setPosition(cw - 8, 12);
      const arrow = s.add.image(3, -1, 'turn-arrow').setOrigin(0.5, 0).setVisible(false);
      c.add([bg, face, name.container, coin, coins.container, star, stars.container, arrow]);
      this.chips.set(p.id, { c, bg, coins, stars, arrow, lastCoins: -1, lastStars: -1 });
      this.objs.push(c);
    });
    this.dice = s.add.sprite(W - 24, H - 26, 'dice', 0).setScrollFactor(0).setDepth(100).setVisible(false);
    this.remaining = new PixelNumber(s, W - 24, H - 56, 3, 0xffe08a, 101); this.remaining.container.setScrollFactor(0);
    this.roundTxt = new PixelNumber(s, 50, H - 12, 1, 0xf6ecd2, 101); this.roundTxt.container.setScrollFactor(0);
    this.starPtr = s.add.image(0, 0, 'big-star').setScrollFactor(0).setDepth(102).setVisible(false).setScale(0.75);
    this.refreshHud();
  }

  private refreshHud() {
    const g = this.game;
    for (const p of g.players) {
      const ch = this.chips.get(p.id)!;
      if (ch.lastCoins !== p.coins) { ch.coins.set(String(p.coins)); ch.lastCoins = p.coins; }
      if (ch.lastStars !== p.stars) { ch.stars.set(String(p.stars)); ch.lastStars = p.stars; }
      const on = p.id === this.active && g.phase !== 'minigame' && g.phase !== 'final';
      ch.arrow.setVisible(on);
      ch.bg.setFillStyle(on ? 0x4a3a8a : 0x1b1030, 0.9);
    }
    this.roundTxt.set(`RODADA ${g.round}/${g.totalRounds}`);
  }

  // ---------------------------------------------------------------- eventos
  private handle(events: GEvent[]) {
    for (const e of events) {
      switch (e.t) {
        case 'turn': this.active = e.pid; this.dice.setVisible(false); this.remaining.set(''); break;
        case 'dice': this.rollDice(e.value); break;
        case 'step': this.hop(e.pid, e.to); this.remaining.set(e.remaining > 0 ? String(e.remaining) : ''); break;
        case 'coins': { const tk = this.tokens.get(e.pid); if (tk) { popup(this.scene, tk.px, tk.py - 26, `${e.delta > 0 ? '+' : '-'}${Math.abs(e.delta)}`, e.delta > 0 ? 0xffe08a : 0xff7a7a, 2); e.delta > 0 ? sfx.coin() : sfx.hit(); } break; }
        case 'teleport': this.teleport(e.pid, e.to); break;
        case 'back': this.slide(e.pid, e.to); break;
        case 'starBuy': if (e.from !== e.to) this.flyStar(e.to); sfx.bigCoin(); break;
        case 'starOffer': sfx.powerup(); break;
        case 'item': sfx.powerup(); break;
        case 'note': if (e.tone === 'bad') sfx.hit(); else if (e.big) sfx.announce(3); break;
        case 'roundStart': this.dice.setVisible(false); this.remaining.set(''); sfx.announce(e.round); break;
        default: break;
      }
    }
  }

  private rollDice(value: number) {
    this.dice.setVisible(true).setAlpha(1);
    const t0 = this.scene.time.now;
    this.rolling = t0 + 800;
    const tick = () => {
      if (!this.dice.active) return;
      if (this.scene.time.now < this.rolling) { this.dice.setFrame(Math.floor(Math.random() * 6)); sfx.tick(); this.scene.time.delayedCall(70, tick); }
      else { this.dice.setFrame(value - 1); this.scene.tweens.add({ targets: this.dice, scale: { from: 1.5, to: 1 }, duration: 160 }); sfx.click(); this.remaining.set(String(value)); }
    };
    tick();
  }

  private hop(pid: string, to: string) {
    const tk = this.tokens.get(pid); if (!tk) return;
    const from = { x: tk.px, y: tk.py };
    tk.tile = to; tk.busy++;
    const t = TILE[to]!;
    // destino já considera quem divide a casa
    const dest = this.slotPos(pid, to);
    tk.sprite.setFrame(this.scene.time.now % 200 < 100 ? 2 : 3);
    const o = { v: 0 };
    this.scene.tweens.add({
      targets: o, v: 1, duration: 300, ease: 'Sine.easeInOut',
      onUpdate: () => { tk.px = from.x + (dest.x - from.x) * o.v; tk.py = from.y + (dest.y - from.y) * o.v; tk.sprite.setPosition(tk.px, tk.py - Math.sin(o.v * Math.PI) * 9); tk.shadow.setPosition(tk.px, tk.py); tk.flag.setPosition(tk.px, tk.py - 22 - Math.sin(o.v * Math.PI) * 9); },
      onComplete: () => { tk.busy--; tk.px = dest.x; tk.py = dest.y; tk.sprite.setPosition(dest.x, dest.y); this.restack(false); },
    });
    void t;
    sfx.tick();
  }

  private slide(pid: string, to: string) {
    const tk = this.tokens.get(pid); if (!tk) return;
    tk.tile = to; tk.busy++;
    const d = this.slotPos(pid, to);
    this.scene.tweens.add({ targets: tk, px: d.x, py: d.y, duration: 450, ease: 'Cubic.easeOut', onUpdate: () => this.place(tk, 0), onComplete: () => { tk.busy--; this.restack(false); } });
    sfx.fall();
  }

  private teleport(pid: string, to: string) {
    const tk = this.tokens.get(pid); if (!tk) return;
    tk.tile = to; tk.busy++;
    sfx.spring();
    this.scene.tweens.add({
      targets: tk.sprite, scaleY: 0, alpha: 0, duration: 220,
      onComplete: () => {
        const d = this.slotPos(pid, to); tk.px = d.x; tk.py = d.y; this.place(tk, 0);
        this.scene.tweens.add({ targets: tk.sprite, scaleY: 1, alpha: 1, duration: 260, onComplete: () => { tk.busy--; this.restack(false); } });
      },
    });
  }

  private flyStar(to: string) {
    const t = TILE[to]!;
    this.scene.tweens.killTweensOf(this.star);
    this.scene.tweens.add({ targets: this.star, x: t.x, y: t.y - 12, duration: 1000, ease: 'Sine.easeInOut' });
    this.scene.tweens.add({ targets: this.glow, x: t.x, y: t.y - 8, duration: 1000, ease: 'Sine.easeInOut' });
  }

  // ---------------------------------------------------------------- posições
  private slotPos(pid: string, tile: string) {
    const here = [...this.tokens.values()].filter((k) => k.tile === tile).sort((a, b) => a.slot - b.slot);
    const idx = Math.max(0, here.findIndex((k) => k.pid === pid));
    const t = TILE[tile]!;
    return { x: t.x + (OFFS[Math.min(4, here.length)] ?? [0])[idx]!, y: t.y + 2 };
  }
  private place(tk: Token, lift: number) {
    tk.sprite.setPosition(tk.px, tk.py - lift); tk.shadow.setPosition(tk.px, tk.py); tk.flag.setPosition(tk.px, tk.py - 22 - lift);
    tk.sprite.setDepth(10 + tk.py / 1000); tk.shadow.setDepth(9); tk.flag.setDepth(60);
  }
  /** Reorganiza quem divide a mesma casa (sem pulos nos que estão andando). */
  private restack(instant: boolean) {
    for (const tk of this.tokens.values()) {
      if (tk.busy) continue;
      const d = this.slotPos(tk.pid, tk.tile);
      if (instant) { tk.px = d.x; tk.py = d.y; this.place(tk, 0); }
      else if (Math.abs(tk.px - d.x) > 0.5 || Math.abs(tk.py - d.y) > 0.5) {
        tk.busy++;
        this.scene.tweens.add({ targets: tk, px: d.x, py: d.y, duration: 160, onUpdate: () => this.place(tk, 0), onComplete: () => { tk.busy--; } });
      }
    }
  }

  // ---------------------------------------------------------------- entradas
  private onKey(ev: KeyboardEvent) {
    if (ev.repeat) return;
    const aw = this.client.state.game?.waiting;
    if (!aw || aw.pid !== this.client.state.you) return;
    const k = ev.code;
    if (aw.kind === 'roll' && (k === 'Space' || k === 'Enter' || k === 'NumpadEnter')) { sfx.click(); this.client.roll?.(); }
    else if (aw.kind === 'buy') {
      if (k === 'Space' || k === 'Enter' || k === 'KeyS' || k === 'KeyY') { this.client.buy?.(true); }
      else if (k === 'Escape' || k === 'KeyN') { this.client.buy?.(false); }
    } else if (aw.kind === 'fork') {
      const dir: Record<string, [number, number]> = { ArrowLeft: [-1, 0], KeyA: [-1, 0], ArrowRight: [1, 0], KeyD: [1, 0], ArrowUp: [0, -1], KeyW: [0, -1], ArrowDown: [0, 1], KeyS: [0, 1] };
      const d = dir[k]; if (!d) return;
      const here = this.tokens.get(aw.pid); if (!here) return;
      const from = TILE[here.tile]!;
      let best: string | null = null, bs = 0.35;
      for (const c of aw.choices) {
        const t = TILE[c]!; const L = Math.hypot(t.x - from.x, t.y - from.y) || 1;
        const dot = ((t.x - from.x) * d[0] + (t.y - from.y) * d[1]) / L;
        if (dot > bs) { bs = dot; best = c; }
      }
      if (best) { sfx.select(); this.client.choose?.(best); }
    }
  }

  // ---------------------------------------------------------------- quadro
  render(time: number) {
    const cl = this.client;
    // consome atualizações do servidor
    for (const u of cl.drainGame?.() ?? []) this.apply(u);
    const g = this.game;
    // ressincroniza peões ociosos que ficaram fora do lugar (reconexão)
    for (const p of g.players) {
      const tk = this.tokens.get(p.id)!;
      if (!tk.busy && tk.tile !== p.tile) { tk.tile = p.tile; this.restack(true); }
    }
    // animação de ocioso: o jogador da vez balança
    const act = this.tokens.get(this.active);
    for (const tk of this.tokens.values()) {
      if (tk.busy) continue;
      const me = tk === act;
      tk.sprite.setFrame(me && Math.floor(time / 450) % 2 ? 1 : 0);
      tk.flag.setY(tk.py - 22 - (me ? Math.abs(Math.sin(time / 260)) * 3 : 0));
    }
    // câmera segue quem joga
    if (act) {
      const tx = this.clampX(act.px - W / 2), ty = this.clampY(act.py - H / 2 - 10);
      this.cam.scrollX += (tx - this.cam.scrollX) * 0.1; this.cam.scrollY += (ty - this.cam.scrollY) * 0.1;
    }
    this.syncPicks(time);
    this.pointStar();
    this.dice.setAlpha(this.game.phase === 'roll' ? 0.5 : 1);
  }

  private apply(u: GameUpdate) {
    this.game = u.game;
    const turn = u.game.order[u.game.turn];
    if (turn && !u.events.some((e) => e.t === 'turn')) this.active = turn;
    this.handle(u.events);
    this.refreshHud();
    this.syncDynamic();
  }

  /** Efeitos temporários do mapa: casas bloqueadas, caminhos novos, brilhos de tesouro e estrela secreta. */
  private syncDynamic() {
    const g = this.game;
    const key = JSON.stringify([g.blocked, g.extraEdges, Object.keys(g.bonusTiles), g.secretStar?.tile ?? '']);
    if (key === this.dynKey) return;
    this.dynKey = key;
    this.dyn.forEach((o) => o.destroy()); this.dyn = [];
    const s = this.scene;
    for (const [a, b] of g.extraEdges) {
      const A = TILE[a]!, B = TILE[b]!;
      const gr = s.add.graphics().setDepth(2);
      gr.lineStyle(10, 0x5a1a0a, 1).lineBetween(A.x, A.y, B.x, B.y);
      gr.lineStyle(6, 0xff9a3a, 1).lineBetween(A.x, A.y, B.x, B.y);
      this.dyn.push(gr);
    }
    for (const id of g.blocked) {
      const t = TILE[id]!;
      const gr = s.add.graphics().setDepth(8);
      gr.fillStyle(0x3a0a0a, 0.8).fillCircle(t.x, t.y, 12);
      gr.lineStyle(3, 0xff6a2a, 1).lineBetween(t.x - 6, t.y - 6, t.x + 6, t.y + 6).lineBetween(t.x + 6, t.y - 6, t.x - 6, t.y + 6);
      this.dyn.push(gr);
    }
    for (const id of Object.keys(g.bonusTiles)) {
      const t = TILE[id]!;
      const sp = s.add.image(t.x + 8, t.y - 12, 'spark').setScale(3).setDepth(45);
      s.tweens.add({ targets: sp, alpha: 0.3, scale: 2, duration: 500, yoyo: true, repeat: -1 });
      this.dyn.push(sp);
    }
    if (g.secretStar) {
      const t = TILE[g.secretStar.tile]!;
      const st = s.add.image(t.x, t.y - 12, 'big-star').setTint(0x66ddff).setScale(0.8).setDepth(40);
      s.tweens.add({ targets: st, y: '-=3', duration: 600, yoyo: true, repeat: -1 });
      this.dyn.push(st);
    }
  }

  /** Setas sobre as casas que o jogador pode escolher na bifurcação. */
  private syncPicks(time: number) {
    const aw = this.client.state.game?.waiting;
    const key = aw?.kind === 'fork' ? aw.choices.join(',') : '';
    if (key !== this.picksKey) {
      this.picks.forEach((o) => o.destroy()); this.picks = []; this.picksKey = key;
      if (aw?.kind === 'fork') for (const c of aw.choices) {
        const t = TILE[c]!;
        const ring = this.scene.add.ellipse(t.x, t.y + 1, 26, 26).setStrokeStyle(2, 0xffe08a).setDepth(7);
        const arr = this.scene.add.image(t.x, t.y - 18, 'pick-arrow').setDepth(70);
        this.picks.push(ring, arr);
      }
    }
    this.picks.forEach((o, i) => { if (i % 2 === 1) (o as Phaser.GameObjects.Image).y = TILE[(aw as { choices: string[] }).choices[(i - 1) / 2]!]!.y - 18 + Math.sin(time / 180) * 2; else (o as Phaser.GameObjects.Ellipse).setAlpha(0.6 + Math.sin(time / 180) * 0.4); });
  }

  /** Estrela fora da tela: ícone na borda apontando para ela. */
  private pointStar() {
    const sx = this.star.x - this.cam.scrollX, sy = this.star.y - this.cam.scrollY;
    const off = sx < 6 || sx > W - 6 || sy < 34 || sy > H - 6;
    this.starPtr.setVisible(off);
    if (off) this.starPtr.setPosition(Math.max(12, Math.min(W - 12, sx)), Math.max(40, Math.min(H - 12, sy)));
  }

  destroy() {
    this.scene.input.keyboard?.off('keydown', this.keyHandler);
    this.scene.input.keyboard?.removeCapture('UP,DOWN,LEFT,RIGHT,SPACE');
    this.cam.removeBounds(); this.cam.setScroll(0, 0);
    this.picks.forEach((o) => o.destroy());
    this.dyn.forEach((o) => o.destroy());
  }
}
