import type Phaser from 'phaser';
import { canvasTex } from './textures';

type Map = Record<string, string>;
function px(ctx: CanvasRenderingContext2D, rows: string[], colors: Map) {
  rows.forEach((row, y) => {
    for (let x = 0; x < row.length; x++) {
      const col = colors[row[x]!];
      if (!col) continue;
      ctx.fillStyle = col;
      ctx.fillRect(x, y, 1, 1);
    }
  });
}
const rect = (ctx: CanvasRenderingContext2D, c: string, x: number, y: number, w: number, h: number) => { ctx.fillStyle = c; ctx.fillRect(x, y, w, h); };

/** Texturas das mecânicas novas da Corrida Maluca (barra, lama, seta, caixa "?", barril, placa, escudo). */
export function buildCorridaArt(scene: Phaser.Scene) {
  // barra pendurada (listrada amarelo/preto: "perigo, abaixe!")
  canvasTex(scene, 'cm-beam', 24, 8, (ctx) => {
    rect(ctx, '#1b1030', 0, 0, 24, 8);
    for (let x = 0; x < 24; x += 6) { rect(ctx, '#ffd23f', x + 1, 1, 3, 6); rect(ctx, '#2a1d4a', x + 4, 1, 3, 6); }
    rect(ctx, '#fff1a8', 1, 1, 22, 1);
    rect(ctx, '#a8741a', 1, 6, 22, 1);
  });
  canvasTex(scene, 'cm-chain', 3, 6, (ctx) => { rect(ctx, '#9aa0b8', 1, 0, 1, 3); rect(ctx, '#5b6285', 1, 3, 1, 3); rect(ctx, '#d6dbf0', 0, 2, 3, 1); });

  // lama
  canvasTex(scene, 'cm-mud', 16, 10, (ctx) => {
    rect(ctx, '#6b4423', 0, 0, 16, 10);
    rect(ctx, '#8a5a30', 0, 0, 16, 2);
    rect(ctx, '#4a2e17', 0, 7, 16, 3);
    px(ctx, ['..b.....b....b..', '.......b........'], { b: '#a8743f' });
    px(ctx, ['................', '................', '....b.......b...', '...bBb.....bBb..'], { b: '#3a2410', B: '#a8743f' });
  });

  // seta de impulso (no chão)
  canvasTex(scene, 'cm-pad', 20, 4, (ctx) => {
    rect(ctx, '#1b1030', 0, 0, 20, 4);
    rect(ctx, '#ffe08a', 1, 1, 18, 2);
    for (let i = 0; i < 3; i++) { const x = 3 + i * 5; rect(ctx, '#d1481a', x, 1, 1, 2); rect(ctx, '#d1481a', x + 1, 0, 1, 1); rect(ctx, '#d1481a', x + 1, 3, 1, 1); rect(ctx, '#d1481a', x + 2, 1, 1, 2); }
  });
  canvasTex(scene, 'cm-padglow', 20, 10, (ctx) => { for (let i = 0; i < 4; i++) { ctx.globalAlpha = 0.18 + i * 0.07; rect(ctx, '#ffe08a', 3 + i, 9 - i * 2 - 1, 14 - i * 2, 2); } ctx.globalAlpha = 1; });

  // caixa "?"
  canvasTex(scene, 'cm-box', 11, 11, (ctx) => {
    px(ctx, [
      'ooooooooooo',
      'oYYYYYYYYYo',
      'oYwwwwwwwYo',
      'oYwpppppwYo',
      'oYwwwwppwYo',
      'oYwwwpppwYo',
      'oYwwwpwwwYo',
      'oYwwwwwwwYo',
      'oYwwwpwwwYo',
      'oYYYYYYYYYo',
      'ooooooooooo',
    ], { o: '#1b1030', Y: '#ffb02e', w: '#ffe9a0', p: '#7a2fd1' });
  });

  // barril (ataque de um rival)
  canvasTex(scene, 'cm-barrel', 12, 13, (ctx) => {
    px(ctx, [
      '..oooooooo..',
      '.oddddddddo.',
      'oBBBBBBBBBBo',
      'oddddddddddo',
      'oddddddddddo',
      'oRRRRRRRRRRo',
      'oddddddddddo',
      'oddddddddddo',
      'oRRRRRRRRRRo',
      'oddddddddddo',
      'oddddddddddo',
      'oBBBBBBBBBBo',
      '.oooooooooo.',
    ], { o: '#1b1030', d: '#9a5a2b', B: '#c98a4a', R: '#d1481a' });
    rect(ctx, '#ff4a4a', 4, 4, 4, 1);
  });

  // placa de aviso (triângulo com seta para baixo) e de "!"
  canvasTex(scene, 'cm-signduck', 14, 15, (ctx) => {
    px(ctx, [
      '......oo......',
      '.....oYYo.....',
      '....oYYYYo....',
      '...oYYddYYo...',
      '..oYYYddYYYo..',
      '..oYYYddYYYo..',
      '.oYYYddddYYYo.',
      '.oYYYYddYYYYo.',
      'oYYYYYddYYYYYo',
      'oYYYYYYYYYYYYo',
      'oYYYYYYYYYYYYo',
      'oooooooooooooo',
      '......pp......',
      '......pp......',
      '......pp......',
    ], { o: '#1b1030', Y: '#ffd23f', d: '#1b1030', p: '#6a5a8a' });
  });
  canvasTex(scene, 'cm-signwarn', 14, 15, (ctx) => {
    px(ctx, [
      '......oo......',
      '.....oRRo.....',
      '....oRRRRo....',
      '...oRRwwRRo...',
      '..oRRRwwRRRo..',
      '..oRRRwwRRRo..',
      '.oRRRRwwRRRRo.',
      '.oRRRRwwRRRRo.',
      'oRRRRRwwRRRRRo',
      'oRRRRRRRRRRRRo',
      'oRRRRRwwRRRRRo',
      'oooooooooooooo',
      '......pp......',
      '......pp......',
      '......pp......',
    ], { o: '#1b1030', R: '#ff4a4a', w: '#ffffff', p: '#6a5a8a' });
  });

  // escudo (bolha) e linha de velocidade
  canvasTex(scene, 'cm-shield', 20, 24, (ctx) => {
    ctx.strokeStyle = '#8fe8ff'; ctx.lineWidth = 1; ctx.globalAlpha = 0.9;
    ctx.beginPath(); ctx.ellipse(10, 12, 9, 11, 0, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 0.18; ctx.fillStyle = '#8fe8ff'; ctx.fill();
    ctx.globalAlpha = 0.9; rect(ctx, '#ffffff', 4, 5, 2, 1); rect(ctx, '#ffffff', 3, 6, 1, 2);
    ctx.globalAlpha = 1;
  });
  canvasTex(scene, 'cm-streak', 10, 1, (ctx) => { ctx.globalAlpha = 0.9; rect(ctx, '#ffffff', 2, 0, 8, 1); ctx.globalAlpha = 0.4; rect(ctx, '#ffffff', 0, 0, 2, 1); ctx.globalAlpha = 1; });
}
