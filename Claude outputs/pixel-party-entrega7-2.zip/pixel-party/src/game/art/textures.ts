import type Phaser from 'phaser';
import { PAL } from './palette';
import { createRng } from '@shared/rng';
import { CHARACTER_IDS, type CharacterId } from '@shared/characters';
import { characterFrame, FRAME_H, FRAME_W, type CharAnim } from './characters';
import { drawPuzzle } from './puzzles';
import { ARENA_H, ARENA_W, TILE, WALL } from '@shared/minigames/caca-moedas';

/**
 * PIPELINE DE ARTE: sprites são mapas de caracteres (índices de cor da paleta),
 * convertidos em texturas por drawMap(). Para novos sprites: escreva o mapa, registre aqui.
 * ('.' = transparente)
 */
type ColorMap = Record<string, string>;

function drawMap(ctx: CanvasRenderingContext2D, rows: string[], colors: ColorMap, ox = 0, oy = 0) {
  rows.forEach((row, y) => {
    for (let x = 0; x < row.length; x++) {
      const c = row[x]!;
      if (c === '.') continue;
      const col = colors[c];
      if (!col) continue;
      ctx.fillStyle = col;
      ctx.fillRect(ox + x, oy + y, 1, 1);
    }
  });
}

export function canvasTex(scene: Phaser.Scene, key: string, w: number, h: number, draw: (ctx: CanvasRenderingContext2D) => void, frames?: { w: number; count: number }) {
  if (scene.textures.exists(key)) return;
  const tex = scene.textures.createCanvas(key, w, h);
  if (!tex) return;
  const ctx = tex.getContext();
  ctx.imageSmoothingEnabled = false;
  draw(ctx);
  if (frames) for (let i = 0; i < frames.count; i++) tex.add(i, 0, i * frames.w, 0, frames.w, h);
  tex.refresh();
}

// ---------- personagens: spritesheet com todas as animações (ver characters.ts) ----------
function buildCharacter(scene: Phaser.Scene, id: CharacterId) {
  const order: [CharAnim, number][] = [['idle', 0], ['idle', 1], ['walk', 0], ['walk', 1], ['celebrate', 0], ['celebrate', 1], ['lose', 0], ['surprised', 0], ['surprised', 1], ['run', 0], ['run', 1], ['jump', 0], ['fall', 0]];
  canvasTex(scene, `char-${id}`, FRAME_W * order.length, FRAME_H, (ctx) => {
    order.forEach(([anim, f], i) => ctx.drawImage(characterFrame(id, anim, f), i * FRAME_W, 0));
  }, { w: FRAME_W, count: order.length });
}

// ---------- moeda: 4 quadros girando ----------
const COIN = [
  '..oooo..', '.oyyyyo.', 'oyyYyyyo', 'oyyYyyyo', 'oyyYyyyo', 'oyyYyyyo', '.oyyyyo.', '..oooo..',
];
function buildCoin(scene: Phaser.Scene) {
  canvasTex(scene, 'coin', 8 * 4, 8, (ctx) => {
    const tmp = document.createElement('canvas');
    tmp.width = 8; tmp.height = 8;
    const t = tmp.getContext('2d')!;
    t.imageSmoothingEnabled = false;
    drawMap(t, COIN, { o: PAL.coinLo, y: PAL.coin, Y: PAL.coinHi });
    const widths = [8, 5, 2, 5];
    widths.forEach((w, i) => ctx.drawImage(tmp, 0, 0, 8, 8, i * 8 + (8 - w) / 2, 0, w, 8));
  }, { w: 8, count: 4 });
}

function buildRock(scene: Phaser.Scene) {
  canvasTex(scene, 'rock', TILE, TILE, (ctx) => {
    drawMap(ctx, [
      '................',
      '....oooooooo....',
      '..ooHHHHSSSSoo..',
      '.oHHHHSSSSSSSso.',
      '.oHHSSSSSSSSSso.',
      'oHHSSSSSDSSSSSso',
      'oHSSSSSSSSSSDSso',
      'oSSSDSSSSSSSSSso',
      'oSSSSSSSSDSSSSdo',
      'oSSSSSSSSSSSSSdo',
      '.oSSSSDSSSSSSdo.',
      '.oSSSSSSSSSSddo.',
      '..oodddddddddoo.',
      '....oooooooooo..',
      '................',
      '................',
    ], { o: PAL.ink, H: PAL.stoneHi, S: PAL.stone1, D: PAL.stone2, d: PAL.stone3 });
  });
}

function buildShadow(scene: Phaser.Scene) {
  canvasTex(scene, 'shadow', 12, 5, (ctx) => {
    drawMap(ctx, ['...xxxxxx...', '.xxxxxxxxxx.', 'xxxxxxxxxxxx', '.xxxxxxxxxx.', '...xxxxxx...'], { x: 'rgba(20,10,40,0.38)' });
  });
}

function buildSpark(scene: Phaser.Scene) {
  canvasTex(scene, 'spark', 3, 3, (ctx) => { drawMap(ctx, ['.y.', 'yYy', '.y.'], { y: PAL.coin, Y: PAL.coinHi }); });
}

function buildMarker(scene: Phaser.Scene) {
  // triângulo apontando para baixo (cor definida por tint)
  canvasTex(scene, 'marker', 7, 4, (ctx) => { drawMap(ctx, ['wwwwwww', '.wwwww.', '..www..', '...w...'], { w: '#ffffff' }); });
}

function buildTree(ctx: CanvasRenderingContext2D, x: number, y: number, r: () => number) {
  // arbusto/árvore em 16x16 com contorno e luz
  drawMap(ctx, [
    '....oooooooo....',
    '..ooLLLLMMMMoo..',
    '.oLLLLMMMMMMMMo.',
    'oLLLMMMMMMMDMMMo',
    'oLLMMMMDMMMMMMDo',
    'oLMMMMMMMMMDMMDo',
    'oMMMDMMMMMMMMDDo',
    'oMMMMMMMDMMMDDDo',
    'oMDMMMMMMMMDDDDo',
    'oMMMMMDMMDDDDDDo',
    '.oMMMMMMDDDDDDo.',
    '.ooMMMDDDDDDDoo.',
    '..ooDDDDDDDDoo..',
    '....ooTTTToo....',
    '.....oTTTTo.....',
    '......oooo......',
  ], { o: PAL.ink, L: '#5fc45a', M: PAL.leaf1, D: PAL.leaf2, T: '#6b4423' }, x, y);
  if (r() < 0.5) { ctx.fillStyle = '#ff8fc1'; ctx.fillRect(x + 4 + Math.floor(r() * 8), y + 4 + Math.floor(r() * 6), 1, 1); }
}

function buildArenaBg(scene: Phaser.Scene) {
  canvasTex(scene, 'arena-bg', ARENA_W, ARENA_H, (ctx) => {
    const rng = createRng(2024);
    // grama xadrez suave + detalhes
    for (let y = 0; y < ARENA_H; y += TILE) {
      for (let x = 0; x < ARENA_W; x += TILE) {
        ctx.fillStyle = ((x / TILE + y / TILE) & 1) === 0 ? PAL.grass1 : PAL.grass2;
        ctx.fillRect(x, y, TILE, TILE);
        for (let i = 0; i < 4; i++) {
          ctx.fillStyle = rng.chance(0.5) ? PAL.grass3 : '#6bc660';
          ctx.fillRect(x + rng.int(0, 15), y + rng.int(0, 15), 1, rng.chance(0.3) ? 2 : 1);
        }
        if (rng.chance(0.04)) { ctx.fillStyle = '#fff3a8'; ctx.fillRect(x + rng.int(2, 13), y + rng.int(2, 13), 2, 2); }
      }
    }
    // anel de árvores
    const r = () => rng.next();
    for (let x = 0; x < ARENA_W; x += TILE) { buildTree(ctx, x, 0, r); buildTree(ctx, x, ARENA_H - WALL, r); }
    for (let y = WALL; y < ARENA_H - WALL; y += TILE) { buildTree(ctx, 0, y, r); buildTree(ctx, ARENA_W - WALL, y, r); }
  });
}

// ---------- texturas da Corrida Maluca ----------
function buildRaceTextures(scene: Phaser.Scene) {
  canvasTex(scene, 'ground', 16, 10, (ctx) => {
    drawMap(ctx, [
      'LLLLLLLLLLLLLLLL', 'GGGGGGGGGGGGGGGG', 'GgGGGgGGGGGgGGGG', 'ddddddddddddddddd'.slice(0, 16),
      'DDDDDDDDDDDDDDDD', 'DDdDDDDDDDdDDDDD', 'DDDDDDdDDDDDDDDD', 'DdDDDDDDDDDdDDDD', 'DDDDDDDDDdDDDDDD', 'dDDDDDDDDDDDDDdD',
    ], { L: '#7fd66a', G: PAL.grass1, g: PAL.grass3, d: '#4a2e16', D: '#7a5230' });
  });
  canvasTex(scene, 'pit', 16, 10, (ctx) => {
    drawMap(ctx, [
      'WwwWWwwWWwwWWwwW', '2222222222222222', '1111111111111111', '1111111111111111', '1111111111111111',
      '1111111111111111', '1111111111111111', '1111111111111111', '1111111111111111', '1111111111111111',
    ], { W: '#9ad0ff', w: '#5e96f0', '2': '#2f6fd0', '1': '#1d3f94' });
  });
  canvasTex(scene, 'plank', 16, 6, (ctx) => {
    drawMap(ctx, ['GGGGGGGGGGGGGGGG', 'oBBBBBBBoBBBBBBB', 'oBbBBBBBoBBbBBBB', 'oBBBBbBBoBBBBBBB', 'oBBBBBBBoBBBBBBB', 'dddddddddddddddd'], { G: PAL.grass1, o: '#3a2410', B: '#b5833f', b: '#8a5a2b', d: '#5a3a1a' });
  });
  canvasTex(scene, 'crate', 12, 13, (ctx) => {
    drawMap(ctx, [
      'oooooooooooo', 'oBBBBBBBBBBo', 'oBobBBBBboBo', 'oBBobBBboBBo', 'oBBBobboBBBo', 'oBBBBooBBBBo', 'oBBBBooBBBBo', 'oBBBobboBBBo', 'oBBobBBboBBo', 'oBobBBBBboBo', 'oBBBBBBBBBBo', 'obbbbbbbbbbo', 'oooooooooooo',
    ], { o: PAL.ink, B: '#d9a441', b: '#a8651a' });
  });
  canvasTex(scene, 'spring', 12, 8, (ctx) => {
    drawMap(ctx, ['.rrrrrrrrrr.', 'orrRRRRRRrro', '.oooooooooo.', '..o.o.o.o...'.slice(0, 12), '...oggggo...', '..oggggggo..'.slice(0, 12), '..oooooooo..', 'oooooooooooo'], { o: PAL.ink, r: '#e05252', R: '#ff9a8a', g: '#9a97ad' });
  });
  canvasTex(scene, 'checker', 8, 8, (ctx) => {
    ctx.fillStyle = '#f4efe0'; ctx.fillRect(0, 0, 8, 8);
    ctx.fillStyle = PAL.ink; ctx.fillRect(0, 0, 4, 4); ctx.fillRect(4, 4, 4, 4);
  });
  canvasTex(scene, 'sky-lane', 480, 67, (ctx) => {
    const bands = ['#4a2f9a', '#5b3ea8', '#7a4fb8', '#a85fb0', '#d9669a', '#f08a8a', '#ffab7a', '#ffc98a'];
    bands.forEach((c, i) => { ctx.fillStyle = c; ctx.fillRect(0, Math.round((i * 67) / bands.length), 480, Math.ceil(67 / bands.length) + 1); });
    ctx.fillStyle = '#fff3c4'; ctx.fillRect(378, 24, 14, 14); ctx.fillRect(380, 22, 10, 18); ctx.fillRect(376, 26, 18, 10);
    const rng = createRng(11);
    for (let i = 0; i < 18; i++) { ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.fillRect(rng.int(0, 479), rng.int(0, 20), 1, 1); }
  });
  canvasTex(scene, 'hills', 128, 40, (ctx) => {
    for (let x = 0; x < 128; x++) {
      const back = 26 + Math.round(6 * Math.sin((x / 128) * Math.PI * 2) + 3 * Math.sin((x / 128) * Math.PI * 6 + 1));
      const front = 32 + Math.round(4 * Math.sin((x / 128) * Math.PI * 4 + 2) + 2 * Math.sin((x / 128) * Math.PI * 8));
      ctx.fillStyle = '#6a3f9f'; ctx.fillRect(x, back, 1, 40 - back);
      ctx.fillStyle = '#2f6f5a'; ctx.fillRect(x, front, 1, 40 - front);
    }
  });
  canvasTex(scene, 'clouds', 160, 30, (ctx) => {
    const c = (x: number, y: number, w: number) => { ctx.fillStyle = 'rgba(255,225,240,0.85)'; ctx.fillRect(x + 3, y, w - 6, 4); ctx.fillRect(x, y + 3, w, 4); ctx.fillStyle = 'rgba(233,168,207,0.8)'; ctx.fillRect(x, y + 6, w, 1); };
    c(10, 4, 26); c(70, 14, 34); c(122, 2, 22);
  });
}

// ---------- texturas do Reflexo Relâmpago e fonte de números ----------
const DIGITS: Record<string, string[]> = {
  '0': ['111', '101', '101', '101', '111'], '1': ['010', '110', '010', '010', '111'], '2': ['111', '001', '111', '100', '111'],
  '3': ['111', '001', '111', '001', '111'], '4': ['101', '101', '111', '001', '001'], '5': ['111', '100', '111', '001', '111'],
  '6': ['111', '100', '111', '101', '111'], '7': ['111', '001', '001', '010', '010'], '8': ['111', '101', '111', '101', '111'],
  '9': ['111', '101', '111', '001', '111'], '+': ['000', '010', '111', '010', '000'], '-': ['000', '000', '111', '000', '000'],
  A: ['010', '101', '111', '101', '101'], B: ['110', '101', '110', '101', '110'], C: ['011', '100', '100', '100', '011'], D: ['110', '101', '101', '101', '110'],
  E: ['111', '100', '110', '100', '111'], F: ['111', '100', '110', '100', '100'], G: ['011', '100', '101', '101', '011'], H: ['101', '101', '111', '101', '101'],
  I: ['111', '010', '010', '010', '111'], J: ['001', '001', '001', '101', '010'], K: ['101', '101', '110', '101', '101'], L: ['100', '100', '100', '100', '111'],
  M: ['101', '111', '111', '101', '101'], N: ['111', '101', '101', '101', '101'], O: ['010', '101', '101', '101', '010'], P: ['110', '101', '110', '100', '100'],
  Q: ['010', '101', '101', '111', '011'], R: ['110', '101', '110', '101', '101'], S: ['011', '100', '010', '001', '110'], T: ['111', '010', '010', '010', '010'],
  U: ['101', '101', '101', '101', '111'], V: ['101', '101', '101', '101', '010'], W: ['101', '101', '111', '111', '101'], X: ['101', '101', '010', '101', '101'],
  Y: ['101', '101', '010', '010', '010'], Z: ['111', '001', '010', '100', '111'], '!': ['010', '010', '010', '000', '010'], '?': ['110', '001', '010', '000', '010'],
  ':': ['000', '010', '000', '010', '000'], '/': ['001', '001', '010', '100', '100'],
};
/** Fonte de pixel 3x5: números, A-Z (sem acento) e alguns símbolos. */
export const DIGIT_FRAMES = '0123456789+-ABCDEFGHIJKLMNOPQRSTUVWXYZ!?:/';

function buildReflexTextures(scene: Phaser.Scene) {
  canvasTex(scene, 'digits', 3 * DIGIT_FRAMES.length, 5, (ctx) => {
    ctx.fillStyle = '#ffffff';
    [...DIGIT_FRAMES].forEach((ch, i) => DIGITS[ch]!.forEach((row, y) => { for (let x = 0; x < 3; x++) if (row[x] === '1') ctx.fillRect(i * 3 + x, y, 1, 1); }));
  }, { w: 3, count: DIGIT_FRAMES.length });
  canvasTex(scene, 'arrow', 14, 14, (ctx) => {
    drawMap(ctx, [
      '......o.......', '......oo......', '......oAo.....', '......oAAo....', 'oooooooAAAo...', 'oAAAAAAAAAAo..', 'oAAAAAAAAAAAo.',
      'oAAAAAAAAAAAo.', 'oAAAAAAAAAAo..', 'oooooooAAAo...', '......oAAo....', '......oAo.....', '......oo......', '......o.......',
    ], { o: PAL.ink, A: '#ffffff' });
  });
  canvasTex(scene, 'check', 12, 12, (ctx) => {
    drawMap(ctx, ['............', '..........oo', '.........ogo', '........ogo.', '.oo....ogo..', 'ogo...ogo...', '.ogo.ogo....', '..ogogo.....', '...ogo......', '....o.......', '............', '............'], { o: PAL.ink, g: '#6dff8a' });
  });
  canvasTex(scene, 'cross', 12, 12, (ctx) => {
    drawMap(ctx, ['............', '.oo......oo.', 'orro....orro', '.orro..orro.', '..orrooorr..', '...orrrro...', '...orrrro...', '..orrooorr..', '.orro..orro.', 'orro....orro', '.oo......oo.', '............'], { o: PAL.ink, r: '#ff5d5d' });
  });
  canvasTex(scene, 'star8', 8, 8, (ctx) => {
    drawMap(ctx, ['...oo...', '..oyyo..', '.oyyyyo.', 'oyyYYyyo', '.oyyyyo.', '.oyooyo.', 'oyo..oyo', 'oo....oo'], { o: PAL.coinLo, y: PAL.coin, Y: PAL.coinHi });
  });
}

function buildBoot(scene: Phaser.Scene) {
  canvasTex(scene, 'boot', 12, 12, (ctx) => {
    drawMap(ctx, [
      '............', '...oooo.....', '...oBBo.....', '...oBBo.....', '...oBBo..y..', '...oBBooo.y.', '..oBBBBBBo..', '.oBBBBBBBBo.', '.oBBBBBBBBo.', '.oWWWWWWWWo.', '.oooooooooo.', '............',
    ], { o: PAL.ink, B: '#3d8bff', W: '#f4efe0', y: PAL.coin });
  });
}

// ---------- texturas do Piso de LED ----------
function buildLedTextures(scene: Phaser.Scene) {
  const T = 34;
  canvasTex(scene, 'led-on', T, T, (ctx) => {
    ctx.fillStyle = PAL.ink; ctx.fillRect(0, 0, T, T);                 // contorno
    ctx.fillStyle = '#9a9a9a'; ctx.fillRect(1, 1, T - 2, T - 2);       // moldura
    ctx.fillStyle = '#ffffff'; ctx.fillRect(3, 3, T - 6, T - 6);       // placa (recebe a cor por tint)
    ctx.fillStyle = 'rgba(0,0,0,0.16)'; ctx.fillRect(3, T - 6, T - 6, 3); ctx.fillRect(T - 6, 3, 3, T - 6); // sombra inferior/direita
    ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.fillRect(5, 5, T - 12, 2); ctx.fillRect(5, 5, 2, T - 12); // brilho
    ctx.fillStyle = 'rgba(0,0,0,0.12)'; ctx.fillRect(T / 2 - 1, 7, 2, T - 14); ctx.fillRect(7, T / 2 - 1, T - 14, 2); // divisões do LED
  });
  canvasTex(scene, 'led-off', T, T, (ctx) => {
    ctx.fillStyle = PAL.ink; ctx.fillRect(0, 0, T, T);
    ctx.fillStyle = '#26204d'; ctx.fillRect(1, 1, T - 2, T - 2);
    ctx.fillStyle = '#14102b'; ctx.fillRect(3, 3, T - 6, T - 6);
    ctx.fillStyle = '#2a2556'; ctx.fillRect(3, 3, T - 6, 1); ctx.fillRect(3, 3, 1, T - 6);
    ctx.fillStyle = '#1d1840'; ctx.fillRect(T / 2 - 1, 7, 2, T - 14); ctx.fillRect(7, T / 2 - 1, T - 14, 2);
  });
  const shapes: string[][] = [
    ['...##...', '...##...', '..####..', '..####..', '.######.', '.######.', '########', '########'],   // triângulo
    ['..####..', '.######.', '########', '########', '########', '########', '.######.', '..####..'],   // círculo
    ['........', '.######.', '.######.', '.######.', '.######.', '.######.', '.######.', '........'],   // quadrado
    ['...##...', '..####..', '.######.', '########', '########', '.######.', '..####..', '...##...'],   // losango
    ['...##...', '...##...', '...##...', '########', '########', '...##...', '...##...', '...##...'],   // cruz
  ];
  shapes.forEach((rows, i) => canvasTex(scene, `shape-${i}`, 8, 8, (ctx) => drawMap(ctx, rows.map((r) => r.replace(/#/g, 'k')), { k: 'rgba(27,16,48,0.85)' })));
}

// ---------- texturas do Último Disparo ----------
function buildDuelTextures(scene: Phaser.Scene) {
  canvasTex(scene, 'pillar', 16, 16, (ctx) => {
    ctx.fillStyle = PAL.ink; ctx.fillRect(0, 0, 16, 16);
    ctx.fillStyle = '#7a7791'; ctx.fillRect(1, 1, 14, 14);
    ctx.fillStyle = '#c8c6d8'; ctx.fillRect(1, 1, 14, 2); ctx.fillRect(1, 1, 2, 14);
    ctx.fillStyle = '#3a3858'; ctx.fillRect(1, 13, 14, 2); ctx.fillRect(13, 1, 2, 14);
    ctx.fillStyle = '#58566f'; ctx.fillRect(4, 4, 8, 8);
    ctx.fillStyle = '#9a97ad'; ctx.fillRect(4, 4, 8, 1); ctx.fillRect(4, 4, 1, 8);
    ctx.fillStyle = '#ffd23d'; for (const [x, y] of [[2, 2], [12, 2], [2, 12], [12, 12]]) ctx.fillRect(x!, y!, 2, 2);
  });
  canvasTex(scene, 'floor-stone', 32, 32, (ctx) => {
    const rng = createRng(91);
    for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++) {
      ctx.fillStyle = (x + y) % 2 === 0 ? '#241e4c' : '#2a2458'; ctx.fillRect(x * 16, y * 16, 16, 16);
      ctx.fillStyle = '#1a1540'; ctx.fillRect(x * 16, y * 16, 16, 1); ctx.fillRect(x * 16, y * 16, 1, 16);
      ctx.fillStyle = '#34306a'; for (let i = 0; i < 4; i++) ctx.fillRect(x * 16 + rng.int(2, 13), y * 16 + rng.int(2, 13), 1, 1);
    }
  });
  canvasTex(scene, 'hazard', 16, 16, (ctx) => {
    for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { ctx.fillStyle = ((x + y) >> 2) % 2 === 0 ? '#ffb02e' : '#2a1a10'; ctx.fillRect(x, y, 1, 1); }
  });
  canvasTex(scene, 'bullet', 8, 8, (ctx) => {
    drawMap(ctx, ['..aaaa..', '.aBBBBa.', 'aBWWWWBa', 'aBWWWWBa', 'aBWWWWBa', 'aBWWWWBa', '.aBBBBa.', '..aaaa..'], { a: '#8a8aa0', B: '#d8d8e8', W: '#ffffff' });
  });
  canvasTex(scene, 'reticle', 26, 26, (ctx) => {
    ctx.fillStyle = '#ffffff';
    for (let a = 0; a < 360; a += 3) { const r = (a * Math.PI) / 180; ctx.fillRect(Math.round(13 + Math.cos(r) * 10), Math.round(13 + Math.sin(r) * 10), 1, 1); }
    for (const [x, y, w, h] of [[12, 0, 2, 5], [12, 21, 2, 5], [0, 12, 5, 2], [21, 12, 5, 2]] as const) ctx.fillRect(x, y, w, h);
  });
}

// ---------- texturas do Duelo de Arqueiros ----------
function bres(ctx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number, col: string) {
  ctx.fillStyle = col;
  let dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx + dy;
  for (;;) { ctx.fillRect(x0, y0, 1, 1); if (x0 === x1 && y0 === y1) break; const e2 = 2 * err; if (e2 >= dy) { err += dy; x0 += sx; } if (e2 <= dx) { err += dx; y0 += sy; } }
}

function buildArcherTextures(scene: Phaser.Scene) {
  canvasTex(scene, 'archer-bg', 480, 270, (ctx) => {
    const rng = createRng(404);
    const cols = ['#1b1050', '#2b1a78', '#43238f', '#6a2f9a', '#9a3f9a', '#c9529a', '#ef7a8a', '#ffa87a', '#ffc98a'];
    cols.forEach((c, i) => { ctx.fillStyle = c; ctx.fillRect(0, i * 21, 480, 22); });
    for (let i = 0; i < 40; i++) { ctx.fillStyle = rng.chance(0.5) ? '#ffffff' : '#cfd2ff'; ctx.fillRect(rng.int(0, 479), rng.int(0, 90), 1, 1); }
    for (let r = 26; r > 0; r -= 4) { ctx.fillStyle = r > 20 ? '#fff6c0' : '#fff0b0'; ctx.beginPath(); ctx.arc(390, 168, r, 0, Math.PI * 2); ctx.fill(); }
    for (let x = 0; x < 480; x++) { const h = 150 + Math.round(Math.sin(x / 37) * 12 + Math.sin(x / 13) * 5); ctx.fillStyle = '#4a2a8c'; ctx.fillRect(x, h, 1, 270 - h); }
    for (let x = 0; x < 480; x++) { const h = 178 + Math.round(Math.sin(x / 23 + 2) * 9 + Math.sin(x / 9) * 3); ctx.fillStyle = '#2c2064'; ctx.fillRect(x, h, 1, 270 - h); }
    for (const [col, base, hmin, hmax, step] of [['#22185a', 214, 28, 52, 13], ['#120c30', 230, 34, 62, 17]] as const) {
      for (let x = -4; x < 490; x += step + rng.int(-3, 4)) { const h = rng.int(hmin, hmax); ctx.fillStyle = col; for (let i = 0; i < h; i += 3) ctx.fillRect(x - Math.round(((h - i) / h) * 9), base - h + i, Math.round(((h - i) / h) * 18) + 1, 3); ctx.fillRect(x - 1, base - 4, 3, 8); }
    }
    ctx.fillStyle = '#0d0828'; ctx.fillRect(0, 232, 480, 38);
  });
  canvasTex(scene, 'dirt', 16, 16, (ctx) => {
    const rng = createRng(7); ctx.fillStyle = '#7a5230'; ctx.fillRect(0, 0, 16, 16);
    for (let i = 0; i < 14; i++) { ctx.fillStyle = rng.chance(0.5) ? '#5a3a1a' : '#8f6238'; ctx.fillRect(rng.int(0, 14), rng.int(0, 14), 2, 1); }
  });
  canvasTex(scene, 'column', 14, 34, (ctx) => {
    ctx.fillStyle = PAL.ink; ctx.fillRect(0, 0, 14, 34);
    ctx.fillStyle = '#7a7791'; ctx.fillRect(1, 1, 12, 32);
    ctx.fillStyle = '#c8c6d8'; ctx.fillRect(1, 1, 3, 32); ctx.fillStyle = '#3a3858'; ctx.fillRect(10, 1, 3, 32);
    ctx.fillStyle = '#58566f'; for (let y = 6; y < 32; y += 8) ctx.fillRect(1, y, 12, 1);
    ctx.fillStyle = '#9a97ad'; ctx.fillRect(0, 0, 14, 4); ctx.fillStyle = PAL.ink; ctx.fillRect(0, 4, 14, 1);
    ctx.fillStyle = '#ffd23d'; ctx.fillRect(5, 12, 4, 4);
  });
  canvasTex(scene, 'bow', 14, 18, (ctx) => {
    for (let y = 0; y < 18; y++) { const x = 4 + Math.round(6 * Math.sin((Math.PI * y) / 17)); ctx.fillStyle = PAL.ink; ctx.fillRect(x - 1, y, 3, 1); ctx.fillStyle = '#b5833f'; ctx.fillRect(x, y, 1, 1); }
    ctx.fillStyle = '#f4efe0'; ctx.fillRect(4, 1, 1, 16);
  });
  canvasTex(scene, 'arrow-n', 14, 3, (ctx) => { ctx.fillStyle = '#cdbf95'; ctx.fillRect(1, 1, 10, 1); ctx.fillStyle = '#e05252'; ctx.fillRect(0, 0, 3, 1); ctx.fillRect(0, 2, 3, 1); ctx.fillStyle = '#cfd2e8'; ctx.fillRect(11, 0, 1, 3); ctx.fillRect(12, 1, 2, 1); });
  canvasTex(scene, 'arrow-f', 14, 3, (ctx) => { ctx.fillStyle = '#8a5a2b'; ctx.fillRect(1, 1, 9, 1); ctx.fillStyle = '#ffb02e'; ctx.fillRect(0, 0, 3, 1); ctx.fillRect(0, 2, 3, 1); ctx.fillStyle = '#ff7a2a'; ctx.fillRect(9, 0, 3, 3); ctx.fillStyle = '#ffd34d'; ctx.fillRect(11, 1, 3, 1); });
  canvasTex(scene, 'heart', 8, 8, (ctx) => { drawMap(ctx, ['.oo..oo.', 'orrooRro', 'orrrrrro', 'orrrrrro', '.orrrro.', '..orro..', '...oo...', '........'], { o: PAL.ink, r: '#ff5d5d', R: '#ffb0b0' }); });
  canvasTex(scene, 'ico-skull', 8, 8, (ctx) => { drawMap(ctx, ['.oooooo.', 'owwwwwwo', 'owwwwwwo', 'oo.ww.oo', 'owwwwwwo', '.owwwwo.', '.owowowo', '..o.o.o.'], { o: PAL.ink, w: '#f4efe0' }); });
  canvasTex(scene, 'ico-target', 8, 8, (ctx) => { drawMap(ctx, ['..oooo..', '.orrrro.', 'orwwwwro', 'orwrrwro', 'orwrrwro', 'orwwwwro', '.orrrro.', '..oooo..'], { o: PAL.ink, r: '#ff5d5d', w: '#f4efe0' }); });
  canvasTex(scene, 'heart-empty', 8, 8, (ctx) => { drawMap(ctx, ['.oo..oo.', 'oddoodd o'.replace(' ', ''), 'odddddd o'.replace(' ', ''), 'odddddd o'.replace(' ', ''), '.odddd o.'.replace(' ', ''), '..oddo..', '...oo...', '........'], { o: PAL.ink, d: '#3a2c4a' }); });
  canvasTex(scene, 'pk-fire', 12, 12, (ctx) => {
    drawMap(ctx, ['.....oo.....', '....oyyo....', '...oyyyyo...', '...oyRRyo...', '..oyyRRyyo..', '..oyRRRRyo..', '.oyyRrrRyyo.', '.oyRrrrrRyo.', '.oyRrrrrRyo.', '..oyRrrRyo..', '...oyyyyo...', '....oooo....'], { o: PAL.ink, y: '#ffd34d', R: '#ff7a2a', r: '#ff4d2a' });
  });
  canvasTex(scene, 'pk-shield', 12, 12, (ctx) => {
    drawMap(ctx, ['.oooooooooo.', 'oBBBBBBBBBBo', 'oBwwBBBBBBBo', 'oBwBBBBBBBBo', 'oBBBBBBBBBBo', 'oBBBBBBBBBBo', '.oBBBBBBBBo.', '.oBBBBBBBBo.', '..oBBBBBBo..', '...oBBBBo...', '....oBBo....', '.....oo.....'], { o: PAL.ink, B: '#4da3ff', w: '#ffffff' });
  });
  canvasTex(scene, 'pk-triple', 12, 12, (ctx) => {
    for (const [x0, y0, x1, y1] of [[1, 6, 9, 6], [1, 10, 8, 3], [1, 2, 8, 9]] as const) bres(ctx, x0, y0, x1, y1, '#f4efe0');
    ctx.fillStyle = '#ffd34d'; for (const [x, y] of [[10, 6], [9, 3], [9, 9]] as const) ctx.fillRect(x, y, 2, 2);
    ctx.fillStyle = '#e05252'; for (const [x, y] of [[0, 6], [0, 10], [0, 2]] as const) ctx.fillRect(x, y, 2, 1);
  });
  canvasTex(scene, 'shield-bubble', 24, 24, (ctx) => {
    for (let a = 0; a < 360; a += 4) { const r = (a * Math.PI) / 180; ctx.fillStyle = a % 40 < 20 ? '#9ad0ff' : '#4da3ff'; ctx.fillRect(Math.round(12 + Math.cos(r) * 10.5), Math.round(12 + Math.sin(r) * 10.5), 1, 1); }
    ctx.fillStyle = 'rgba(120,200,255,0.18)'; ctx.beginPath(); ctx.arc(12, 12, 10, 0, Math.PI * 2); ctx.fill();
  });
}

export function buildAllTextures(scene: Phaser.Scene) {
  buildArcherTextures(scene);
  buildDuelTextures(scene);
  buildLedTextures(scene);
  buildBoot(scene);
  buildRaceTextures(scene);
  buildReflexTextures(scene);
  for (const id of CHARACTER_IDS) buildCharacter(scene, id);
  buildCoin(scene);
  buildRock(scene);
  buildShadow(scene);
  buildSpark(scene);
  buildMarker(scene);
  buildArenaBg(scene);
}

/** Cria (uma vez) as texturas de uma imagem do quebra-cabeça: a imagem inteira e as 16 peças 6x6. */
export function ensurePuzzleTextures(scene: Phaser.Scene, picture: number) {
  canvasTex(scene, `puzfull-${picture}`, 24, 24, (ctx) => drawPuzzle(picture, ctx));
  canvasTex(scene, `puzp-${picture}`, 6 * 16, 6, (ctx) => {
    const tmp = document.createElement('canvas'); tmp.width = 24; tmp.height = 24;
    const t = tmp.getContext('2d')!; drawPuzzle(picture, t);
    for (let k = 0; k < 16; k++) ctx.drawImage(tmp, (k % 4) * 6, Math.floor(k / 4) * 6, 6, 6, k * 6, 0, 6, 6);
  }, { w: 6, count: 16 });
}
