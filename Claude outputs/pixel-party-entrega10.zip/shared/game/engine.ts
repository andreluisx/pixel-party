/**
 * Motor da partida de tabuleiro. Puro e determinístico (rng dentro do estado), sem relógio e sem rede:
 * o servidor chama act() com a intenção de quem joga e advance() para cada passo automático.
 */
import type { Board } from '../board/types';
import type { MinigameResult } from '../minigame';
import { nextRandom } from '../rng';
import type { BotDifficulty, BotPersonality, PlayerId, Slot } from '../types';

export const TOTAL_ROUNDS = 12;
export const START_COINS = 10;
export const STAR_COST = 20;
export const MAX_BONUS_PER_ROUND = 1;

export type Phase = 'round_start' | 'roll' | 'moving' | 'fork' | 'tile' | 'star_offer' | 'minigame' | 'round_end' | 'final';
export type CoinReason = 'inicio' | 'casa azul' | 'casa vermelha' | 'tesouro' | 'armadilha' | 'evento' | 'minigame' | 'estrela';

export interface GPlayer {
  id: PlayerId; slot: Slot; name: string; characterId: string; isBot: boolean;
  difficulty?: BotDifficulty; personality?: BotPersonality;
  tile: string; coins: number; stars: number; wins: number; steps: number;
  trail: string[]; // últimas casas visitadas (a mais recente por último)
}
export interface CoinEntry { round: number; pid: PlayerId; delta: number; reason: string; balance: number }
export interface GameState {
  rng: number;
  board: string;
  round: number; totalRounds: number;
  order: PlayerId[]; turn: number; phase: Phase;
  players: GPlayer[];
  starTile: string;
  move: { pid: PlayerId; remaining: number; prev: string | null; choices: string[]; forced: string | null } | null;
  mg: { id: string; context: 'tile' | 'round'; seq: number } | null;
  mgSeq: number; bonusUsed: number;
  mgHistory: string[];
  appliedRewards: string[];
  coinLog: CoinEntry[];
  mgIds: string[];
  mgWeights: Record<string, number>;
  final: Standing[] | null;
}
export interface Standing { pid: PlayerId; rank: number; stars: number; coins: number; wins: number }

export type Intent = { kind: 'roll' } | { kind: 'choose'; tile: string } | { kind: 'buy'; yes: boolean };
export type Awaiting =
  | { pid: PlayerId; kind: 'roll' }
  | { pid: PlayerId; kind: 'fork'; choices: string[] }
  | { pid: PlayerId; kind: 'buy' };

export type GEvent =
  | { t: 'roundStart'; round: number; final: boolean; order: PlayerId[] }
  | { t: 'turn'; pid: PlayerId }
  | { t: 'dice'; pid: PlayerId; value: number }
  | { t: 'step'; pid: PlayerId; from: string; to: string; remaining: number }
  | { t: 'fork'; pid: PlayerId; choices: string[] }
  | { t: 'coins'; pid: PlayerId; delta: number; reason: string }
  | { t: 'tile'; pid: PlayerId; tile: string; type: string; msg: string }
  | { t: 'teleport'; pid: PlayerId; from: string; to: string }
  | { t: 'back'; pid: PlayerId; to: string }
  | { t: 'starBuy'; pid: PlayerId; from: string; to: string }
  | { t: 'starOffer'; pid: PlayerId }
  | { t: 'minigame'; id: string; context: 'tile' | 'round' }
  | { t: 'roundEnd'; round: number }
  | { t: 'final'; standings: Standing[] };

export interface CreateOpts {
  board: Board; seed: number; mgIds: string[];
  players: Array<Pick<GPlayer, 'id' | 'slot' | 'name' | 'characterId' | 'isBot' | 'difficulty' | 'personality'>>;
  totalRounds?: number;
  mgWeights?: Record<string, number>;
}

const rnd = (s: GameState) => nextRandom(s);
const rint = (s: GameState, a: number, b: number) => Math.floor(rnd(s) * (b - a + 1)) + a;
const P = (s: GameState, id: PlayerId) => s.players.find((p) => p.id === id)!;
export const activePid = (s: GameState) => s.order[s.turn]!;

export function createGame(o: CreateOpts): GameState {
  const s: GameState = {
    rng: o.seed | 0, board: o.board.def.id, round: 1, totalRounds: o.totalRounds ?? TOTAL_ROUNDS,
    order: [], turn: 0, phase: 'round_start', players: [], starTile: '', move: null, mg: null, mgSeq: 0, bonusUsed: 0,
    mgHistory: [], appliedRewards: [], coinLog: [], mgIds: o.mgIds, mgWeights: o.mgWeights ?? {}, final: null,
  };
  const start = o.board.def.tiles.find((t) => t.start)!.id;
  s.players = o.players.map((p) => ({ ...p, tile: start, coins: START_COINS, stars: 0, wins: 0, steps: 0, trail: [start] }));
  const ids = s.players.map((p) => p.id);
  for (let i = ids.length - 1; i > 0; i--) { const j = rint(s, 0, i); [ids[i], ids[j]] = [ids[j]!, ids[i]!]; }
  s.order = ids;
  s.starTile = o.board.def.starSpots[rint(s, 0, o.board.def.starSpots.length - 1)]!;
  return s;
}

export function awaiting(s: GameState): Awaiting | null {
  const pid = activePid(s);
  if (s.phase === 'roll') return { pid, kind: 'roll' };
  if (s.phase === 'fork' && s.move) return { pid, kind: 'fork', choices: s.move.choices };
  if (s.phase === 'star_offer') return { pid, kind: 'buy' };
  return null;
}
/** true se o motor segue sozinho com advance() */
export const isAuto = (s: GameState) => awaiting(s) === null && s.phase !== 'minigame' && s.phase !== 'final';

export function addCoins(s: GameState, pid: PlayerId, delta: number, reason: string, ev?: GEvent[]): number {
  const p = P(s, pid);
  const real = Math.max(delta, -p.coins);
  p.coins += real;
  s.coinLog.push({ round: s.round, pid, delta: real, reason, balance: p.coins });
  if (real !== 0) ev?.push({ t: 'coins', pid, delta: real, reason });
  return real;
}

/** Intenção de um jogador. Valida vez, fase e caminho; o valor do dado é sorteado aqui (servidor). */
export function act(s: GameState, board: Board, pid: PlayerId, intent: Intent): { ok: boolean; error?: string; events: GEvent[] } {
  const ev: GEvent[] = [];
  const aw = awaiting(s);
  if (!aw) return { ok: false, error: 'Agora não é hora de agir', events: ev };
  if (aw.pid !== pid) return { ok: false, error: 'Não é a sua vez', events: ev };
  if (intent.kind !== (aw.kind === 'fork' ? 'choose' : aw.kind)) return { ok: false, error: 'Ação inválida agora', events: ev };
  if (intent.kind === 'roll') {
    const value = rint(s, 1, 6);
    s.move = { pid, remaining: value, prev: null, choices: [], forced: null };
    s.phase = 'moving';
    ev.push({ t: 'dice', pid, value });
  } else if (intent.kind === 'choose') {
    if (aw.kind !== 'fork' || !aw.choices.includes(intent.tile)) return { ok: false, error: 'Caminho inválido', events: ev };
    s.move!.forced = intent.tile; s.phase = 'moving';
  } else if (intent.kind === 'buy') {
    if (intent.yes) buyStar(s, board, pid, ev);
    if (s.move && s.move.remaining > 0) s.phase = 'moving'; // estava só passando pelo altar: segue o caminho
    else nextTurn(s, ev);
  }
  return { ok: true, events: ev };
}

function buyStar(s: GameState, board: Board, pid: PlayerId, ev: GEvent[]) {
  const p = P(s, pid);
  if (p.coins < STAR_COST || p.tile !== s.starTile) return;
  addCoins(s, pid, -STAR_COST, 'estrela', ev);
  p.stars++;
  const from = s.starTile;
  const spots = board.def.starSpots.filter((x) => x !== from);
  const far = spots.filter((x) => board.dist(x, p.tile) >= 5);
  const pool = far.length ? far : [spots.sort((a, b) => board.dist(b, p.tile) - board.dist(a, p.tile))[0]!];
  s.starTile = pool[rint(s, 0, pool.length - 1)]!;
  ev.push({ t: 'starBuy', pid, from, to: s.starTile });
}

function nextTurn(s: GameState, ev: GEvent[]) {
  s.move = null;
  s.turn++;
  if (s.turn >= s.order.length) { s.phase = 'round_end'; return; }
  s.phase = 'roll';
  ev.push({ t: 'turn', pid: activePid(s) });
}

export function pickMinigame(s: GameState): string {
  const prev = s.mgHistory[s.mgHistory.length - 1];
  const cand = s.mgIds.filter((id) => id !== prev);
  const pool = cand.length ? cand : s.mgIds;
  const w = pool.map((id) => (s.mgWeights[id] ?? 1) * Math.pow(0.35, s.mgHistory.filter((h) => h === id).length));
  let r = rnd(s) * w.reduce((a, b) => a + b, 0);
  for (let i = 0; i < pool.length; i++) { r -= w[i]!; if (r <= 0) return pool[i]!; }
  return pool[pool.length - 1]!;
}

function startMinigame(s: GameState, context: 'tile' | 'round', ev: GEvent[]) {
  const id = pickMinigame(s);
  s.mgHistory.push(id);
  s.mg = { id, context, seq: ++s.mgSeq };
  s.phase = 'minigame';
  ev.push({ t: 'minigame', id, context });
}

/** Um passo automático. Devolve os eventos para o cliente animar. */
export function advance(s: GameState, board: Board): GEvent[] {
  const ev: GEvent[] = [];
  switch (s.phase) {
    case 'round_start': {
      s.turn = 0; s.bonusUsed = 0; s.phase = 'roll';
      ev.push({ t: 'roundStart', round: s.round, final: s.round === s.totalRounds, order: [...s.order] });
      ev.push({ t: 'turn', pid: activePid(s) });
      break;
    }
    case 'moving': {
      const m = s.move!; const p = P(s, m.pid);
      if (m.remaining <= 0) { s.phase = 'tile'; break; }
      let choices = board.adj[p.tile]!.filter((n) => n !== m.prev);
      if (!choices.length) choices = [...board.adj[p.tile]!];
      let to = m.forced;
      m.forced = null;
      if (!to) {
        if (choices.length > 1) { m.choices = choices; s.phase = 'fork'; ev.push({ t: 'fork', pid: m.pid, choices }); break; }
        to = choices[0]!;
      }
      const from = p.tile;
      p.tile = to; p.steps++; m.prev = from; m.remaining--;
      p.trail.push(to); if (p.trail.length > 8) p.trail.shift();
      ev.push({ t: 'step', pid: m.pid, from, to, remaining: m.remaining });
      if (m.remaining === 0) s.phase = 'tile';
      else if (p.tile === s.starTile && p.coins >= STAR_COST) { s.phase = 'star_offer'; ev.push({ t: 'starOffer', pid: p.id }); } // passou pelo altar com moedas: pode comprar
      break;
    }
    case 'tile': {
      const p = P(s, activePid(s)); const t = board.byId[p.tile]!;
      const msg = (m: string) => ev.push({ t: 'tile', pid: p.id, tile: t.id, type: t.type, msg: m });
      let after: 'next' | 'star' | 'mg' = 'next';
      switch (t.type) {
        case 'blue': addCoins(s, p.id, 3, 'casa azul', ev); msg('+3 moedas'); break;
        case 'red': addCoins(s, p.id, -3, 'casa vermelha', ev); msg('-3 moedas'); break;
        case 'treasure': { const v = rint(s, 5, 15); addCoins(s, p.id, v, 'tesouro', ev); msg('Tesouro!'); break; }
        case 'trap':
          if (rnd(s) < 0.5) { addCoins(s, p.id, -3, 'armadilha', ev); msg('Armadilha! -3'); }
          else {
            const idx = Math.max(0, p.trail.length - 3);
            const to = p.trail[idx]!;
            p.trail = p.trail.slice(0, idx + 1); p.tile = to;
            msg('Armadilha! Volta 2'); ev.push({ t: 'back', pid: p.id, to });
          }
          break;
        case 'teleport': {
          const others = board.def.tiles.filter((x) => x.type === 'teleport' && x.id !== t.id);
          const to = others[rint(s, 0, others.length - 1)]!.id;
          p.tile = to; p.trail.push(to);
          msg('Teleporte!'); ev.push({ t: 'teleport', pid: p.id, from: t.id, to });
          break;
        }
        case 'event': {
          const v = rint(s, -2, 5);
          if (v) addCoins(s, p.id, v, 'evento', ev);
          msg(v >= 0 ? 'Evento: sorte!' : 'Evento: azar');
          break;
        }
        case 'shop': msg('Loja (em breve)'); break;
        case 'duel': msg('Duelo (em breve)'); break;
        case 'minigame':
          if (s.bonusUsed < MAX_BONUS_PER_ROUND) { s.bonusUsed++; msg('Minigame extra!'); after = 'mg'; } else msg('Já teve minigame extra');
          break;
        case 'star':
          if (t.id === s.starTile && p.coins >= STAR_COST) { msg('A estrela! 20 moedas'); after = 'star'; }
          else msg(t.id === s.starTile ? 'Faltam moedas para a estrela' : 'Altar sem estrela');
          break;
      }
      if (after === 'star') { s.phase = 'star_offer'; ev.push({ t: 'starOffer', pid: p.id }); }
      else if (after === 'mg') { s.move = null; startMinigame(s, 'tile', ev); }
      else nextTurn(s, ev);
      break;
    }
    case 'round_end': {
      ev.push({ t: 'roundEnd', round: s.round });
      startMinigame(s, 'round', ev);
      break;
    }
    default: break;
  }
  return ev;
}

/** Aplica o resultado do minigame (idempotente por sequência) e segue o fluxo. */
export function finishMinigame(s: GameState, result: MinigameResult, rewards: Record<PlayerId, number>): GEvent[] {
  const ev: GEvent[] = [];
  if (s.phase !== 'minigame' || !s.mg) return ev;
  const key = `mg-${s.mg.seq}`;
  if (s.appliedRewards.includes(key)) return ev;
  s.appliedRewards.push(key);
  for (const p of s.players) addCoins(s, p.id, rewards[p.id] ?? 0, 'minigame', ev);
  if (result.kind === 'ranking') for (const e of result.ranking) if (e.rank === 1) P(s, e.playerId).wins++;
  const ctx = s.mg.context;
  s.mg = null;
  if (ctx === 'tile') { nextTurn(s, ev); return ev; }
  if (s.round >= s.totalRounds) {
    s.final = standings(s); s.phase = 'final';
    ev.push({ t: 'final', standings: s.final });
  } else {
    s.round++; s.order.push(s.order.shift()!); s.phase = 'round_start';
  }
  return ev;
}

export function standings(s: GameState): Standing[] {
  const arr = s.players.map((p) => ({ pid: p.id, stars: p.stars, coins: p.coins, wins: p.wins, rank: 0 }));
  const key = (x: Standing) => [x.stars, x.coins, x.wins];
  arr.sort((a, b) => { const A = key(a), B = key(b); for (let i = 0; i < 3; i++) if (A[i] !== B[i]) return B[i]! - A[i]!; return 0; });
  arr.forEach((x, i) => {
    const prev = arr[i - 1];
    x.rank = prev && key(prev).join() === key(x).join() ? prev.rank : i + 1;
  });
  return arr;
}

/** Estado enviado aos clientes (sem a semente do sorteio). */
export function publicGame(s: GameState): Omit<GameState, 'rng' | 'coinLog' | 'appliedRewards'> & { coinLog: CoinEntry[] } {
  const { rng: _r, appliedRewards: _a, ...rest } = s;
  return { ...rest, coinLog: s.coinLog.slice(-40) };
}
