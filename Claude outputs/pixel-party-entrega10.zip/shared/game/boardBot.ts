import type { Board, TileType } from '../board/types';
import { nextRandom } from '../rng';
import type { BotDifficulty, BotPersonality } from '../types';
import type { GameState, Intent } from './engine';
import { awaiting, STAR_COST } from './engine';

const BASE: Record<TileType, number> = { blue: 3, red: -3, treasure: 6, trap: -2, teleport: 1, event: 1, shop: 0.5, duel: 1, minigame: 1.5, star: 0 };
const PERS: Record<BotPersonality, Partial<Record<TileType, number>>> = {
  collector: { blue: 2, treasure: 3 },
  aggressive: { duel: 4, minigame: 3 },
  careful: { red: -4, trap: -5 },
  gambler: { event: 4, treasure: 2, teleport: 3, trap: 1 },
};
const RANDOMNESS: Record<BotDifficulty, number> = { easy: 0.4, medium: 0.15, hard: 0.03 };

/** Decide pela vez; usa só o estado público. Sempre devolve uma intenção válida. */
export function decide(s: GameState, board: Board, rng: { rng: number }): Intent | null {
  const aw = awaiting(s);
  if (!aw) return null;
  if (aw.kind === 'roll') return { kind: 'roll' };
  const p = s.players.find((x) => x.id === aw.pid)!;
  if (aw.kind === 'buy') return { kind: 'buy', yes: p.coins >= STAR_COST };
  const pers = p.personality ?? 'collector';
  const rand = RANDOMNESS[p.difficulty ?? 'medium'];
  if (nextRandom(rng) < rand) return { kind: 'choose', tile: aw.choices[Math.floor(nextRandom(rng) * aw.choices.length)]! };
  const reach = s.move?.remaining ?? 1;
  let best = aw.choices[0]!, bestScore = -Infinity;
  for (const c of aw.choices) {
    // olha as casas até `remaining` passos à frente, sem voltar
    let score = 0; let frontier = [{ id: c, prev: p.tile }];
    for (let d = 0; d < Math.min(reach, 4) && frontier.length; d++) {
      const nxt: typeof frontier = [];
      for (const f of frontier) {
        const t = board.byId[f.id]!;
        const w = (BASE[t.type] + (PERS[pers][t.type] ?? 0)) / (d + 1);
        score += w;
        if (t.id === s.starTile && p.coins >= STAR_COST) score += pers === 'collector' ? 12 : 8;
        for (const n of board.adj[f.id]!) if (n !== f.prev) nxt.push({ id: n, prev: f.id });
      }
      frontier = nxt.slice(0, 12);
    }
    const goal = p.coins >= STAR_COST ? s.starTile : null;
    if (goal) score -= board.dist(c, goal) * (pers === 'collector' ? 1.5 : 0.8);
    score += nextRandom(rng) * 0.5;
    if (score > bestScore) { bestScore = score; best = c; }
  }
  return { kind: 'choose', tile: best };
}
