'use client';
import { useEffect, useRef, useState } from 'react';
import type Phaser from 'phaser';
import type { RoomClient, RoomClientState } from '@/net/roomClient';
import type { RoomState } from '@shared/protocol';
import { SLOT_COLORS } from '@shared/types';
import { MINIGAME_LIST } from '@shared/minigames';
import { createGame } from '@/game/createGame';
import { sfx } from '@/game/audio/sfx';
import { ActionButton, DPad, FireButton, ModeToggle, ResultTable, RobotIcon, TouchPad } from './Lab';

/** Tela da partida: o tabuleiro (Phaser) + avisos, pedidos de ação e os minigames da própria sala. */
export function MatchStage({ client, st, room }: { client: RoomClient; st: RoomClientState; room: RoomState }) {
  const stage = useRef<HTMLDivElement>(null);
  const [hud, setHud] = useState<{ t: number; text?: string; locked?: boolean; scores: Record<string, number> }>({ t: 0, scores: {} });
  const [toast, setToast] = useState<RoomClientState['toast']>(null);
  const isHost = room.hostId === st.you;
  const game = st.game?.game ?? null;
  const waiting = st.game?.waiting ?? null;
  const phase = st.lobby?.phase ?? 'lobby';
  const meta = st.intro?.meta;
  const players = st.intro?.participants ?? room.participants;
  const mine = !!waiting && waiting.pid === st.you;
  const who = waiting ? game?.players.find((p) => p.id === waiting.pid) : null;

  useEffect(() => {
    let g: Phaser.Game | null = null; let cancelled = false;
    (async () => {
      if ('fonts' in document) { try { await document.fonts.load('700 16px "Pixelify Sans"'); } catch { /* fallback */ } }
      if (cancelled || !stage.current) return;
      g = await createGame(stage.current, client, () => false);
      if (cancelled) g.destroy(true);
    })();
    (window as unknown as { __roomClient?: RoomClient }).__roomClient = client; // testes automatizados
    return () => { cancelled = true; g?.destroy(true); };
  }, [client]);

  useEffect(() => {
    const id = setInterval(() => { const s = client.latest; if (s) setHud({ t: s.timeLeftMs, text: s.hudText, locked: s.locked, scores: s.scores }); }, 100);
    return () => clearInterval(id);
  }, [client]);

  useEffect(() => {
    if (!st.toast) return;
    setToast(st.toast);
    const id = setTimeout(() => setToast(null), 2300);
    return () => clearTimeout(id);
  }, [st.toast]);

  useEffect(() => { if (st.countdown === null) return; if (st.countdown === 0) sfx.go(); else sfx.beep(); }, [st.countdown]);
  useEffect(() => { if (st.result) sfx.win(); }, [st.result]);
  useEffect(() => { if (game?.phase === 'final') sfx.win(); }, [game?.phase]);

  const showIntro = phase === 'intro' && st.intro;
  const showCount = phase === 'countdown' && st.countdown !== null;
  const onBoard = !st.intro;
  const final = game?.phase === 'final' ? game.final : null;
  const nameOf = (id: string) => game?.players.find((p) => p.id === id);
  const fmt = MINIGAME_LIST.find((m) => m.id === meta?.id)?.formatScore;

  return (
    <section className="match">
      <div className="stage-wrap">
        <div className="stage" data-testid="match-stage">
          <div ref={stage} className="stage-canvas" />

          {onBoard && !final && toast && <div key={toast.key} className={`match-toast tone-${toast.tone}`} role="status">{toast.text}</div>}

          {onBoard && game && !final && waiting && (
            <div className="prompt" role="group" aria-live="polite">
              {mine && waiting.kind === 'roll' && <button className="btn btn-gold prompt-btn" data-testid="roll" onClick={() => { sfx.click(); client.roll(); }}>Rolar o dado <kbd>Espaço</kbd></button>}
              {mine && waiting.kind === 'fork' && <p className="prompt-msg">Escolha o caminho: toque numa casa marcada ou use as setas</p>}
              {mine && waiting.kind === 'buy' && (
                <div className="prompt-row">
                  <span className="prompt-msg">Comprar a estrela por 20 moedas?</span>
                  <button className="btn btn-gold" data-testid="buy-yes" onClick={() => client.buy(true)}>Comprar</button>
                  <button className="btn" data-testid="buy-no" onClick={() => client.buy(false)}>Agora não</button>
                </div>
              )}
              {!mine && who && (
                <p className="prompt-msg" style={{ borderColor: SLOT_COLORS[who.slot] }}>
                  {who.isBot ? <>{who.name} <RobotIcon /> está pensando…</> : <>Vez de {who.name}…</>}
                </p>
              )}
            </div>
          )}

          {phase === 'active' && !meta?.hideHud && (
            <div className="hud">
              <div className="hud-time">{hud.text ?? Math.ceil(hud.t / 1000)}</div>
              <ul className="hud-scores">
                {players.map((p) => (
                  <li key={p.id} style={{ borderColor: SLOT_COLORS[p.slot] }} className={p.id === st.you ? 'me' : ''}>
                    <span className="dot" style={{ background: SLOT_COLORS[p.slot] }} />{p.name}{p.isBot && <RobotIcon />}<b>{hud.scores[p.id] ?? 0}{meta?.hudUnit ?? ''}</b>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {showIntro && st.intro && (
            <div className="overlay center">
              <div className="card intro">
                <h2>{st.intro.meta.instructions.title}</h2>
                <ul>{st.intro.meta.instructions.lines.map((l) => <li key={l}>{l}</li>)}</ul>
                <div className="controls">{st.intro.meta.instructions.controls.map((c) => <span key={c.keys}><kbd>{c.keys}</kbd> {c.action}</span>)}</div>
                <div className="bar"><div className="bar-fill" /></div>
              </div>
            </div>
          )}
          {showCount && <div className="overlay center"><div className="count" key={st.countdown}>{st.countdown === 0 ? 'VAI!' : st.countdown}</div></div>}

          {phase === 'result' && st.result && (
            <div className="overlay center">
              <div className="card result">
                <h2>Resultado do minigame</h2>
                <ResultTable result={st.result.result} rewards={st.result.rewards} players={players} you={st.you} format={fmt} />
                <p className="hint">As moedas já foram para o seu saldo. Voltando ao tabuleiro…</p>
              </div>
            </div>
          )}

          {final && (
            <div className="overlay center">
              <div className="card result final" data-testid="final">
                <h2>Fim de jogo!</h2>
                <ol className="rank">
                  {final.map((s) => {
                    const p = nameOf(s.pid);
                    return (
                      <li key={s.pid} className={s.pid === st.you ? 'rank-you' : ''}>
                        <span className="rank-pos">{s.rank}º</span>
                        <span className="dot" style={{ background: SLOT_COLORS[p?.slot ?? 0] }} />
                        <span className="rank-name">{p?.name}{p?.isBot && <RobotIcon />}</span>
                        <span className="rank-score">{s.stars} ★</span>
                        <span className="rank-coins">{s.coins} moedas</span>
                        <small className="rank-detail">{s.wins} minigame(s) vencido(s)</small>
                      </li>
                    );
                  })}
                </ol>
                <p className="hint">Desempate: estrelas, depois moedas, depois minigames vencidos.</p>
                <div className="actions">
                  {isHost && <button className="btn btn-gold" onClick={() => { sfx.click(); client.backToLobby(); }}>Voltar ao lobby</button>}
                  <button className="btn" onClick={() => { sfx.click(); client.leave(); }}>Sair da sala</button>
                </div>
              </div>
            </div>
          )}

          {phase === 'active' && meta?.instructions.touch?.stick !== false && <TouchPad client={client} />}
          {phase === 'active' && meta?.instructions.touch?.dpad && <DPad client={client} />}
          {phase === 'active' && meta?.instructions.touch?.fire && <FireButton client={client} label={meta.instructions.touch.fire} />}
          {phase === 'active' && meta?.instructions.touch?.aimToggle && <ModeToggle client={client} aim={st.aimMode} locked={!!hud.locked} />}
          {phase === 'active' && meta?.instructions.touch?.action && <ActionButton client={client} label={meta.instructions.touch.action} />}
        </div>
        <p className="hint under">
          {onBoard ? 'Tabuleiro: Espaço rola o dado · setas/WASD ou toque escolhem o caminho · estrela custa 20 moedas.' : meta ? meta.instructions.controls.map((c) => `${c.keys}: ${c.action}`).join(' · ') : ''}
        </p>
        {!final && <div className="actions match-actions"><button className="btn btn-sm" onClick={() => { sfx.click(); client.leave(); }}>Sair da partida</button>{isHost && <button className="btn btn-sm" onClick={() => { sfx.click(); client.backToLobby(); }}>Encerrar e voltar ao lobby</button>}</div>}
      </div>
    </section>
  );
}
